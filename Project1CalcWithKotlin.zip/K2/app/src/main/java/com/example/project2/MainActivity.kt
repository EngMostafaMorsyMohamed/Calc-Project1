package com.example.project2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var n1 =0
        var n2=0

        fun setNum(){
            n1=num1.text.toString().toInt()
            n2=num2.text.toString().toInt()
        }
        add.setOnClickListener(){
            setNum()
            resualt.text= (n1+n2).toString()
        }
        sub.setOnClickListener(){
            setNum()
            resualt.text= (n1-n2).toString()
        }
            multi.setOnClickListener(){
            setNum()
            resualt.text= (n1*n2).toString()
        }

        div.setOnClickListener(){
            setNum()
            resualt.text= (n1/n2).toString()
        }


    }
}